import coursesJson from "../data/courses.json"

export async function fetchCourses() {
  return coursesJson
}
