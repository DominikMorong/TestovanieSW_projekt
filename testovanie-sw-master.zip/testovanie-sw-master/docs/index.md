# Real World Testing with Cypress

Real World Testing with Cypress is built with [Next.js](https://nextjs.org). Check out the various links in the left-hand sidebar for more documentation.
