# Utils

## machineUtils.ts

Contains several utility methods used for fetching lesson data and state from `machines/progressMachine.ts`

## mdxUtils.ts

Contains several utility methods used for fetching _courses_ and _real world examples_ content files and data from the `/content` directory.
