import cliTruncate from "cli-truncate"

describe('template spec', () => {
  beforeEach(() => {
    cy.visit('https://ais2.ukf.sk/ais/start.do')
  })

  // it("should contain nieco", () => {
  //   cy.getByData('hero-heading').contains("Testing Next.js Applications with Cypress")
  // })
  //
  // it("Prihlasit sa do newsTellera", () => {
  //   cy.getByData("email-input").type("dodo@gmail.com")
  //   cy.getByData("submit-button").click()
  //   cy.getByData("success-message").should("exist").contains("dodo@gmail.com")
  // })
  //
  // it("Nerihlasit sa do newsTellera", () => {
  //   cy.getByData("email-input").type("dodogmail.com")
  //   cy.getByData("submit-button").click()
  //   cy.getByData("success-message").should("not.exist")
  // })
  it("Prihlasit sa do AIS", () => {
    cy.get('#login').type("312405");
    cy.get('#heslo').type("0003062917");
    cy.get('#login-form-submit-btn').click()
    // chyba otazka na to ci som sa naozaj uspesne prihlasil
  })

})