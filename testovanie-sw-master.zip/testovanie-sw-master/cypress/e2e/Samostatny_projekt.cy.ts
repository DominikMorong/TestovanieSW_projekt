// @ts-ignore
describe('Testovanie tlačidla Kontakt', () => {
  beforeEach(() => {
    // Pred každým testom navštívi hlavnú stránku
    cy.visit('https://ais2.ukf.sk/ais/start.do');
  });

  it('Tlačidlo "Kontakt" je viditeľné na hlavnej stránke', () => {
    // Overí, či je tlačidlo viditeľné
    cy.getKontakt().should('be.visible')
  });

  it('Tlačidlo "Kontakt" má správny nápis', () => {
    // Overí, či má tlačidlo správny text
    cy.getKontakt().should('contain.text', 'Kontakt');
  });

  it('Kliknutie na tlačidlo "Kontakt" presmeruje na stránku s kontaktmi', () => {
    // Klikne na tlačidlo a overí presmerovanie
    cy.getKontakt().click();
    cy.url().should('include', '/changeTab.do?tab=3');
  });

  it('Tlačidlo "Kontakty" je funkčné po obnovení stránky', () => {
    // Obnoví stránku a overí funkčnosť tlačidla
    cy.reload();
    cy.getKontakt().click();
    cy.url().should('include', '/changeTab.do?tab=3');
  });
});